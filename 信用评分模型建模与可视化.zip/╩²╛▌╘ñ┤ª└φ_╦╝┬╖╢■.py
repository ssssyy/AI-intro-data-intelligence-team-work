# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import pandas as pd
import matplotlib.pyplot as plt #导入图像库
from sklearn.ensemble import RandomForestRegressor
import numpy as np
# 用随机森林对缺失值预测填充函数
def set_missing(df):
    # 把已有的数值型特征取出来
    process_df = df.ix[:,[5,0,1,2,3,4,6,7,8,9]]
    # 分成已知该特征和未知该特征两部分
    known = process_df[process_df.MonthlyIncome.notnull()].values
    unknown = process_df[process_df.MonthlyIncome.isnull()].values
    # X为特征属性值
    X = known[:, 1:]
    # y为结果标签值
    y = known[:, 0]
    # fit到RandomForestRegressor之中
    rfr = RandomForestRegressor(random_state=0, n_estimators=200,max_depth=3,n_jobs=-1)
    rfr.fit(X,y)
    # 用得到的模型进行未知特征值预测
    predicted = rfr.predict(unknown[:, 1:]).round(0)
    #print(predicted)
    # 用得到的预测结果填补原缺失数据
    df.loc[(df.MonthlyIncome.isnull()), 'MonthlyIncome'] = predicted
    return df

if __name__ == '__main__':
    #载入数据
    data = pd.read_csv(r'cs-training.csv',encoding = 'utf-8')
    del data['Unnamed: 0']
    #数据集确实和分布情况
    #data.describe().to_csv('DataDescribe.csv')#了解数据集的分布情况
    data = set_missing(data)#用随机森林填补比较多的缺失值，主要是MonthlyIncome和家庭成员NA
    data = data.dropna()#删除比较少的缺失值
    data = data.drop_duplicates()#删除重复项
	#观察填充后数据各项的离群值情况
    data.describe().to_csv('MissingDataDescribe.csv')
	
	
    #异常值处理
    #年龄等于0和年龄大于100的异常值进行剔除
    data=data[data['age']>0]
    data = data[data['age'] <= 100]
    data = data[data['NumberOfTime30-59DaysPastDueNotWorse'] < 90]#剔除异常值
    
    data = data[data['DebtRatio'] <= 10]#负债率大于10的舍弃，与作图时的标准相同
    data = data[data['RevolvingUtilizationOfUnsecuredLines'] <= 1]#该比率理应小于等于1，剔除异常值
    loc = data['SeriousDlqin2yrs']
    data.drop(labels=['SeriousDlqin2yrs'],axis=1,inplace=True)
    data.insert(10,'SeriousDlqin2yrs',loc)
    data.drop(labels=['DebtRatio'],axis=1,inplace=True)
    data.drop(labels=['MonthlyIncome'],axis=1,inplace=True)
    data.drop(labels=['NumberOfOpenCreditLinesAndLoans'],axis=1,inplace=True)
    data.drop(labels=['NumberRealEstateLoansOrLines'],axis=1,inplace=True)
    data.drop(labels=['NumberOfDependents'],axis=1,inplace=True)
    data.to_csv(r'NewData2.csv',index=False)
    
    
#在新的思路中合并了三种不同时长的逾期数目和两种不同的贷款数目    
    data = pd.read_csv("NewData.csv")
    data.insert(data.shape[1],"逾期总次数",0)
    data.insert(data.shape[1],"贷款总数",0)
    data["贷款总数"]+=data['NumberOfOpenCreditLinesAndLoans']
    data["贷款总数"]+=data['NumberRealEstateLoansOrLines']
    data.drop(labels=['NumberOfOpenCreditLinesAndLoans'],axis=1,inplace=True)
    data.drop(labels=['NumberRealEstateLoansOrLines'],axis=1,inplace=True)
    data["逾期总次数"]+=data['NumberOfTime3059DaysPastDueNotWorse']
    data["逾期总次数"]+=data['NumberOfTime6089DaysPastDueNotWorse']
    data["逾期总次数"]+=data['NumberOfTimes90DaysLate']
    data.drop(labels=['NumberOfTime3059DaysPastDueNotWorse'],axis=1,inplace=True)
    data.drop(labels=['NumberOfTime6089DaysPastDueNotWorse'],axis=1,inplace=True)
    data.drop(labels=['NumberOfTimes90DaysLate'],axis=1,inplace=True)
    data.to_csv(r'NewData3.csv',index=False)