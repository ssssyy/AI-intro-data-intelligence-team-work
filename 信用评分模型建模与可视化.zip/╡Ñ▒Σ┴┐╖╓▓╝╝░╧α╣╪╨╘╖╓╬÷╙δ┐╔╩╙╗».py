import numpy as np
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
import matplotlib.ticker as ticker
import pandas as pd

fileName = 'cs-training.csv'
plt.rcParams['font.sans-serif'] = 'SimHei'      #设置字体为SimHei显示中文
plt.rcParams['axes.unicode_minus'] = False      #正常显示负号

#RevolvingUtilizationOfUnsecuredLines
with open(fileName) as csvfile:
    # 定义两个空列表
    tem = []  # 暂时储存读取的数据
    y = [0] * 11
    plots = pd.read_csv(csvfile)
    #设置图片分辨率等参数
    plt.figure(figsize=(15,8),dpi=200)
    #设置坐标轴字体大小
    plt.tick_params(labelsize = 20)
    for i in plots['RevolvingUtilizationOfUnsecuredLines']:    #将读取的数据保存在临时列表中
        tem.append(float(i))
    #以0.1为组距
    for i in tem:
        if i > 1:
            y[10] += 1
        else:
            y[int(i/0.1)] += 1
    #横坐标名字
    x = range(0,11)
    x_name = ['0.0-0.1','0.1-0.2','0.2-0.3','0.3-0.4','0.4-0.5','0.5-0.6','0.6-0.7','0.7-0.8','0.8-0.9','0.9-1','>1']
    #bar的返回值为一组柱子
    b = plt.bar(x_name,y,width=0.6)
    #给每个柱子上面添加具体数值
    for i in b:
        h = i.get_height()
        plt.text(i.get_x()+i.get_width()/2,h,'%d'%int(h),ha = 'center',va = 'bottom',fontsize = 16)
    plt.xticks(x,x_name)
    #储存图片
    plt.savefig('./RevolvingUtilizationOfUnsecuredLines.jpg')
    plt.show()

#Age
with open(fileName) as csvfile:
    # 定义两个空列表
    tem = []  # 暂时储存读取的数据
    y = [0] * 10
    plots = pd.read_csv(csvfile)
    #设置图片分辨率等参数
    plt.figure(figsize=(15,8),dpi=200)
    #设置坐标轴字体大小
    plt.tick_params(labelsize = 20)
    for i in plots['age']:    #将读取的数据保存在临时列表中
        tem.append(int(i))
    #以10为组距
    for i in tem:
        if i == 10:
            y[9] += 1
        else:
            y[int(i/10)] += 1
    #横坐标名字
    x = range(0,10)
    x_name = ['0-10','10-20','20-30','30-40','40-50','50-60','60-70','70-80','80-90','90-100']
    #bar的返回值为一组柱子
    b = plt.bar(x_name,y,width=0.6)
    #给每个柱子上面添加具体数值
    for i in b:
        h = i.get_height()
        plt.text(i.get_x()+i.get_width()/2,h,'%d'%int(h),ha = 'center',va = 'bottom',fontsize = 16)
    plt.xticks(x,x_name)
    #储存图片
    plt.savefig('./Age.jpg')
    plt.show()

#NumberOfTime30-59DaysPastDueNotWorse
with open(fileName) as csvfile:
    # 定义两个空列表
    tem = []  # 暂时储存读取的数据
    y = [0] * 15
    plots = pd.read_csv(csvfile)
    #设置图片分辨率等参数
    plt.figure(figsize=(15,8),dpi=200)
    #设置坐标轴字体大小
    plt.tick_params(labelsize = 20)
    for i in plots['NumberOfTime30-59DaysPastDueNotWorse']:    #将读取的数据保存在临时列表中
        tem.append(int(i))
    #以1为组距
    for i in tem:
            y[i] += 1
    #横坐标名字
    x = range(0,15)
    #bar的返回值为一组柱子
    b = plt.bar(x,y,width=0.6)
    #给每个柱子上面添加具体数值
    for i in b:
        h = i.get_height()
        plt.text(i.get_x()+i.get_width()/2,h,'%d'%int(h),ha = 'center',va = 'bottom',fontsize = 16)
    plt.xticks(x,x)
    #储存图片
    plt.savefig('./NumberOfTime30_59DaysPastDueNotWorse.jpg')
    plt.show()

#DebtRadio
with open(fileName) as csvfile:
    # 定义两个空列表
    tem = []  # 暂时储存读取的数据
    y = [0] * 13
    plots = pd.read_csv(csvfile)
    #设置图片分辨率等参数
    plt.figure(figsize=(17,8),dpi=200)
    #设置坐标轴字体大小
    plt.tick_params(labelsize = 17)
    for i in plots['DebtRatio']:    #将读取的数据保存在临时列表中
        tem.append(float(i))
    #设置组距组距
    for i in tem:
        if i >= 10:
            y[12] += 1
        elif i >= 5:
            y[11] += 1
        elif i >= 1:
            y[10] += 1
        else:
            y[int(i/0.1)] += 1
    #横坐标名字
    x = range(0,13)
    x_name = ['0.0-0.1','0.1-0.2','0.2-0.3','0.3-0.4','0.4-0.5','0.5-0.6','0.6-0.7','0.7-0.8','0.8-0.9','0.9-1','1-5','5-10','10-15']
    #bar的返回值为一组柱子
    b = plt.bar(x,y,width=0.6)
    #给每个柱子上面添加具体数值
    for i in b:
        h = i.get_height()
        plt.text(i.get_x()+i.get_width()/2,h,'%d'%int(h),ha = 'center',va = 'bottom',fontsize = 16)
    plt.xticks(x,x_name)
    #储存图片
    plt.savefig('./DebtRatio.jpg')
    plt.show()

#MonthlyIncome
with open(fileName) as csvfile:
    # 定义两个空列表
    tem = []  # 暂时储存读取的数据
    y = [0] * 17
    plots = pd.read_csv(csvfile)
    #设置图片分辨率等参数
    plt.figure(figsize=(20,8),dpi=200)
    #设置坐标轴字体大小
    plt.tick_params(labelsize = 17)
    for i in plots['MonthlyIncome']:    #将读取的数据保存在临时列表中
        tem.append(int(i))
    #设置组距组距
    for i in tem:
        if i >= 20000:
            y[16] += 1
        elif i >= 15000:
            y[15] += 1
        else:
            y[int(i/1000)] += 1
    #横坐标名字
    x = range(0,17)
    x_name = ['0-1','1-2','2-3','3-4','4-5','5-6','6-7','7-8','8-9','9-10','10-11','11-12','12-13','13-14','14-15','15-20','>20']
    #bar的返回值为一组柱子
    b = plt.bar(x,y,width=0.6)
    #给每个柱子上面添加具体数值
    for i in b:
        h = i.get_height()
        plt.text(i.get_x()+i.get_width()/2,h,'%d'%int(h),ha = 'center',va = 'bottom',fontsize = 16)
    plt.xticks(x,x_name)
    plt.xlabel('MonthlyIncome/k',fontsize = 16)
    #储存图片
    plt.savefig('./MonthlyIncome.jpg')
    plt.show()

#NumberOfOpenCreditLinesAndLoans
with open(fileName) as csvfile:
    # 定义两个空列表
    tem = []  # 暂时储存读取的数据
    y = [0] * 6
    plots = pd.read_csv(csvfile)
    #设置图片分辨率等参数
    plt.figure(figsize=(15,8),dpi=200)
    #设置坐标轴字体大小
    plt.tick_params(labelsize = 17)
    for i in plots['NumberOfOpenCreditLinesAndLoans']:    #将读取的数据保存在临时列表中
        tem.append(int(i))
    #设置组距组距
    for i in tem:
            y[int(i/10)] += 1
    #横坐标名字
    x = range(0,6)
    x_name = ['0-10','10-20','20-30','30-40','40-50','50-60']
    #bar的返回值为一组柱子
    b = plt.bar(x,y,width=0.6)
    #给每个柱子上面添加具体数值
    for i in b:
        h = i.get_height()
        plt.text(i.get_x()+i.get_width()/2,h,'%d'%int(h),ha = 'center',va = 'bottom',fontsize = 16)
    plt.xticks(x,x_name)
    plt.xlabel('NumberOfOpenCreditLinesAndLoans',fontsize = 16)
    #储存图片
    plt.savefig('./NumberOfOpenCreditLinesAndLoans.jpg')
    plt.show()

#NumberOfTimes90DaysLate/NumberOfTime60-89DaysPastDueNotWorse 0 1图
with open(fileName) as csvfile:
    # 定义两个空列表
    tem = []  # 暂时储存读取的数据
    y = [0] * 2
    plots = pd.read_csv(csvfile)
    #设置图片分辨率等参数
    plt.figure(figsize=(6,8),dpi=200)
    #设置坐标轴字体大小
    plt.tick_params(labelsize = 17)
    for i in plots['NumberRealEstateLoansOrLines']:    #将读取的数据保存在临时列表中
        tem.append(int(i))
    #设置组距组距
    for i in tem:
            if i >= 1:
                y[1] += 1
            else:
                y[0] += 1
    #横坐标名字
    x = range(0,2)
    #bar的返回值为一组柱子
    b = plt.bar(x,y,width=0.3)
    #给每个柱子上面添加具体数值
    for i in b:
        h = i.get_height()
        plt.text(i.get_x()+i.get_width()/2,h,'%d'%int(h),ha = 'center',va = 'bottom',fontsize = 16)
    plt.xticks(x,x)
    plt.xlabel('NumberRealEstateLoansOrLines',fontsize = 16)
    #储存图片
    plt.savefig('./NumberRealEstateLoansOrLines.jpg')
    plt.show()

#NumberOfDependent
with open(fileName) as csvfile:
    # 定义两个空列表
    tem = []  # 暂时储存读取的数据
    y = [0] * 11
    plots = pd.read_csv(csvfile)
    #设置图片分辨率等参数
    plt.figure(figsize=(15,8),dpi=200)
    #设置坐标轴字体大小
    plt.tick_params(labelsize = 17)
    for i in plots['NumberOfDependents']:    #将读取的数据保存在临时列表中
        tem.append(int(i))
    #设置组距组距
    for i in tem:
            if i >= 10:
                y[10] += 1
            else:
                y[i] += 1
    #横坐标名字
    x = range(0,11)
    x_name = [0,1,2,3,4,5,6,7,8,9,'>10']
    #bar的返回值为一组柱子
    b = plt.bar(x,y,width=0.6)
    #给每个柱子上面添加具体数值
    for i in b:
        h = i.get_height()
        plt.text(i.get_x()+i.get_width()/2,h,'%d'%int(h),ha = 'center',va = 'bottom',fontsize = 16)
    plt.xticks(x,x_name)
    plt.xlabel('NumberOfDependents',fontsize = 16)
    #储存图片
    plt.savefig('./NumberOfDependents.jpg')
    plt.show()

#MonthlyIncome与其他的相关性散点图
with open(fileName) as csvfile:
    plots = pd.read_csv(csvfile)
    #设置图片分辨率等参数
    plt.figure(figsize=(15,10),dpi=200)
    plt.xlabel('MonthlyIncome',fontsize = 20)
    plt.ylabel('NumberOfDependents',fontsize = 20)
    #设置坐标轴字体大小
    plt.tick_params(labelsize = 20)
    plt.scatter(plots['MonthlyIncome'],plots['NumberOfDependents'],s = 2)
    #储存图片
    plt.savefig('./MonthlyIncome_NumberOfDependents.jpg')
    plt.show()
