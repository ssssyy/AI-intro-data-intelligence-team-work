# -*- coding: utf-8 -*-
"""
Created on Wed May  6 18:09:05 2020

@author: smile
"""
import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
data = pd.read_csv('NewData2.csv')
data1 = pd.read_csv('NewData4.csv')
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso
from sklearn.linear_model import ElasticNet
from sklearn.preprocessing import PolynomialFeatures
from sklearn.model_selection import train_test_split
from sklearn.cross_validation import cross_val_score
from sklearn.metrics import roc_curve,auc
from sklearn.metrics.regression import mean_squared_error, r2_score
X=data[['RevolvingUtilizationOfUnsecuredLines','age','NumberOfTime30-59DaysPastDueNotWorse','NumberOfTime60-89DaysPastDueNotWorse','NumberOfTime60-89DaysPastDueNotWorse']]
y=data[['SeriousDlqin2yrs']]
X1=data1[['RevolvingUtilizationOfUnsecuredLines','age','NumberOfDependents','SumOfLate']]
y1=data1[['SeriousDlqin2yrs']]
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.4,random_state=0)
X_train1,X_test1,y_train1,y_test1=train_test_split(X1,y1,test_size=0.4,random_state=0)


print("线性回归")
liner = LinearRegression()
result1 = liner.fit(X_train,y_train)
y_predl1 = liner.predict(X_test)
print("Linear1:")
print("系数为：",liner.coef_)
print("截距为：",liner.intercept_)
print("均方误差：",mean_squared_error(y_predl1,y_test))
print("相关系数：",r2_score(y_test,y_predl1))
print("5折交叉检验得分:",cross_val_score(liner, X, y, cv=5))
result2 = liner.fit(X_train1,y_train)
y_predl2 = liner.predict(X_test1)
print("Linear2:")
print("系数为：",liner.coef_)
print("截距为：",liner.intercept_)
print("均方误差：",mean_squared_error(y_predl2,y_test1))
print("相关系数：",r2_score(y_test1,y_predl2))
print("5折交叉检验得分:",cross_val_score(liner, X1, y1, cv=5))
print("\n")

print("多项式回归")
#二次多项式拟合
quadratic_featurizer = PolynomialFeatures(degree=2)
X_train_quadratic = quadratic_featurizer.fit_transform(X_train)
X_test_quadratic = quadratic_featurizer.transform(X_test)
regressor_quadratic = LinearRegression()
regressor_quadratic.fit(X_train_quadratic, y_train)
y_predP2 = regressor_quadratic.predict(X_test_quadratic)
print("系数为：",regressor_quadratic.coef_)
print("截距为：",regressor_quadratic.intercept_)
print("2 r-squared", mean_squared_error(y_predP2,y_test))
print(r2_score(y_test,y_predP2))
print(cross_val_score(regressor_quadratic, X, y, cv=5))

#三次多项式拟合
cubic_featurizer = PolynomialFeatures(degree=3)
X_train_cubic = cubic_featurizer.fit_transform(X_train)
X_test_cubic = cubic_featurizer.transform(X_test)
regressor_cubic = LinearRegression()
regressor_cubic.fit(X_train_cubic, y_train)
y_predP3 = regressor_cubic.predict(X_test_cubic)
'''print("系数为：",regressor_cubic.coef_)
print("截距为：",regressor_cubic.intercept_)'''
print("3 r-squared", mean_squared_error(y_predP3,y_test))
print(r2_score(y_test,y_predP3))


#四次多项式拟合
fourth_featurizer = PolynomialFeatures(degree=4)
X_train_fourth = fourth_featurizer.fit_transform(X_train)
X_test_fourth = fourth_featurizer.transform(X_test)
regressor_fourth = LinearRegression()
regressor_fourth.fit(X_train_fourth, y_train)
y_predP4 = regressor_fourth.predict(X_test_fourth)
'''print("系数为：",regressor_fourth.coef_)
print("截距为：",regressor_fourth.intercept_)'''
print("4 r-squared", mean_squared_error(y_predP4,y_test))
print(r2_score(y_test,y_predP4))

print("逻辑斯蒂回归")
model=LogisticRegression()
model2=LogisticRegression()
result=model.fit(X_train,y_train)
result2 = model2.fit(X_train1,y_train)
print("Logistic1得分:",result.score(X_test,y_test))
print("Logistic2得分:",result2.score(X_test1,y_test1))
y_pred = result.predict(X_test)
y_pred1 = result2.predict(X_test1)
print("五个因子回归系数为：",model.coef_)
print("截距为：",model.intercept_)
print("均方误差:",mean_squared_error(y_pred,y_test))
print("四个因子回归系数为：",model2.coef_)
print("截距为：",model2.intercept_)
print("均方误差:",mean_squared_error(y_pred1,y_test1))


#以下是另外试了三种线性型回归方程以及输出其均方误差
ridge = Ridge()
lasso = Lasso()
elasticnet = ElasticNet()
result1 = ridge.fit(X_train,y_train)
result2 = lasso.fit(X_train,y_train)
result3 = elasticnet.fit(X_train,y_train)
y_pre_ridge = ridge.predict(X_test)
y_pre_lasso = lasso.predict(X_test)
y_pre_elasticnet = elasticnet.predict(X_test)
print("ridge:",mean_squared_error(y_pre_ridge,y_test))
print("lasso:",mean_squared_error(y_pre_lasso,y_test))
print("elasticnet：",mean_squared_error(y_pre_elasticnet,y_test))

