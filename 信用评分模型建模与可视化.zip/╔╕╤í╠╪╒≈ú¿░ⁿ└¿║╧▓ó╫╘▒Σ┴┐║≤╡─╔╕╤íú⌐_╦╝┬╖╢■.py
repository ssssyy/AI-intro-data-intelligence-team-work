# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import numpy as np
import pandas as pd
pd.set_option('display.max_columns',20)
#数据读取
#利用pandas读取csv，读取的数据为DataFrame对象

data = pd.read_csv('NewData.csv')
loc = data['SeriousDlqin2yrs']
data.drop(labels=['SeriousDlqin2yrs'],axis=1,inplace=True)
data.insert(10,'SeriousDlqin2yrs',loc)
data1 = pd.read_csv('NewData3.csv')
loc1 = data1['SeriousDlqin2yrs']
data1.drop(labels=['SeriousDlqin2yrs'],axis=1,inplace=True)
data1.insert(7,'SeriousDlqin2yrs',loc)
print(data1)
# 将DataFrame对象转化为数组,数组的最后一列为预报对象
print(data)
print("转换后的data")
data= data.values.copy()
data1= data1.values.copy()
print(data)
 
# 计算回归系数，参数
def get_regre_coef(X,Y):
    S_xy=0
    S_xx=0
    S_yy=0
    # 计算预报因子和预报对象的均值
    X_mean = np.mean(X)
    Y_mean = np.mean(Y)
    for i in range(len(X)):
        S_xy += (X[i] - X_mean) * (Y[i] - Y_mean)
        S_xx += pow(X[i] - X_mean, 2)
        S_yy += pow(Y[i] - Y_mean, 2)
    return S_xy/pow(S_xx*S_yy,0.5)
#构建原始增广矩阵
def get_original_matrix():
    # 创建一个数组存储相关系数,data.shape几行(维)几列，结果用一个tuple表示
    # print(data.shape[1])
    col=data.shape[1]
    # print(col)
    r=np.ones((col,col))#np.ones参数为一个元组(tuple)
    # print(np.ones((col,col)))
    # for row in data.T:#运用数组的迭代，只能迭代行，迭代转置后的数组，结果再进行转置就相当于迭代了每一列
        # print(row.T)
    for i in range(col):
        for j in range(col):
            r[i,j]=get_regre_coef(data[:,i],data[:,j])
    return r

def get_vari_contri(r):
    col = data.shape[1]
     #创建一个矩阵来存储方差贡献值
    v=np.ones((1,col-1))
    # print(v)
    for i in range(col-1):
        # v[0,i]=pow(r[i,col-1],2)/r[i,i]
        v[0, i] = pow(r[i, col - 1], 2) / r[i, i]
    return v
#选择因子是否进入方程，
#参数说明：r为增广矩阵，v为方差贡献值，k为方差贡献值最大的因子下标,p为当前进入方程的因子数
def select_factor(r,v,k,p):
    row=data.shape[0]#样本容量
    col=data.shape[1]-1#预报因子数
    #计算方差比
    f=(row-p-2)*v[0,k-1]/(r[col,col]-v[0,k-1])
    # print(calc_vari_contri(r))
    return f

def delete_factor(r,v,k,t):
    row = data.shape[0]  # 样本容量
    col = data.shape[1] - 1  # 预报因子数
    # 计算方差比
    f = (row - t - 1) * v[0, k - 1] / r[col, col]
    # print(calc_vari_contri(r))
    return f


#通过矩阵转换公式来计算各部分增广矩阵的元素值
def convert_matrix(r,k):
    col=data.shape[1]
    k=k-1#从第零行开始计数
    #第k行的元素单不属于k列的元素
    r1 = np.ones((col, col))  # np.ones参数为一个元组(tuple)
    for i in range(col):
        for j in range(col):
            if (i==k and j!=k):
                r1[i,j]=r[k,j]/r[k,k]
            elif (i!=k and j!=k):
                r1[i,j]=r[i,j]-r[i,k]*r[k,j]/r[k,k]
            elif (i!= k and j== k):
                r1[i,j] = -r[i,k]/r[k,k]
            else:
                r1[i,j] = 1/r[k,k]
    return r1


#计算第零步增广矩阵
r=get_original_matrix()
print(r)
#计算方差贡献值
v=get_vari_contri(r)
print(data1.columns)
print(v)

#用F检验决定是否引入新的预报因子以及是否删除已引入的预报因子

'''['RevolvingUtilizationOfUnsecuredLines', 'age',
       'NumberOfTime30-59DaysPastDueNotWorse', 'DebtRatio', 'MonthlyIncome',
       'NumberOfOpenCreditLinesAndLoans', 'NumberOfTimes90DaysLate',
       'NumberRealEstateLoansOrLines', 'NumberOfTime60-89DaysPastDueNotWorse',
       'NumberOfDependents', 'SeriousDlqin2yrs']'''
'''[[5.69252900e-02 9.19655714e-03 6.12883525e-02 6.70703859e-04
  2.81998025e-04 2.56048675e-04 8.40371476e-02 7.39481904e-05
  5.74472498e-02 1.94204543e-03]]'''
#总共十个自变量，其中方差贡献大的是7,3,9,1,2；较小的是8,6,5,4,10
#计算方差比，先引入贡献最大的

'''计算整合了贷款总数以及逾期总次数后的新因子的贡献'''
data2=data
data=data1
r1=get_original_matrix()
v1=get_vari_contri(r1)
print(v1)
data=data2
'''[[0.05692529 0.00919656 0.0006707  0.000282   0.00194205 0.12798763 0.00016016]]'''
'''从上表可见，逾期总次数(6)占比最大，其次是信用额度比(1)、年龄(2)、家庭人数(5)
考虑舍去影响不高的因子347'''
data1 = pd.DataFrame(data1)
print(data1)
data1.drop(labels=[2],axis=1,inplace=True)
data1.drop(labels=[3],axis=1,inplace=True)
data1.drop(labels=[6],axis=1,inplace=True)
data1.to_csv(r'NewData4.csv',index=False)



'''以下是对原始数据集（十个特征的操作）'''
#引入因子7
f=select_factor(r,v,7,0)
print(f)
#f = 10724.804334192628
#矩阵转换，计算第一步矩阵
r=convert_matrix(r,7)
print(r)
#计算第一步方差贡献值
v=get_vari_contri(r)
print(v)
'''[[0.03242445 0.00562654 0.03718986 0.00078174 0.00012871 0.00010397
  0.08403715 0.00060864 0.0277144  0.00127295]]'''

#引入因子3
f=select_factor(r,v,3,1)
print(f)
#f=4946.979074886382
r=convert_matrix(r,3)
v=get_vari_contri(r)
print(v)
'''[[2.20638017e-02 4.42696652e-03 3.71898609e-02 4.60050609e-04
  1.49293738e-04 8.76399062e-05 5.99386560e-02 1.73889521e-04
  1.50420266e-02 6.43648632e-04]]'''

#引入因子1
f=select_factor(r,v,1,2)
print(f)
#f=3010.4777764682162
r=convert_matrix(r,1)
v=get_vari_contri(r)
print(v)
'''[[2.20638017e-02 9.87044630e-04 2.68292100e-02 3.03136291e-04
  6.30812204e-05 1.91748526e-04 4.57046737e-02 4.90525560e-04
  1.25569558e-02 2.17177978e-04]]'''

#引入因子9
f=select_factor(r,v,9,3)
print(f)
#f=1738.794987046963
r=convert_matrix(r,9)
v=get_vari_contri(r)
print(v)
'''[[1.95787309e-02 8.98909651e-04 1.77693912e-02 3.01088635e-04
  5.66726111e-05 2.15525122e-04 3.41025163e-02 5.32472697e-04
  1.25569558e-02 1.93226778e-04]]'''

'''开始考虑删除因子，从最小的已引入因子开始'''
#引入因子2
f=select_factor(r,v,2,4)
print(f)
#f=124.60602882249513
r=convert_matrix(r,2)
v=get_vari_contri(r)
print(v)
'''[[1.65264016e-02 8.98909651e-04 1.77847110e-02 3.32638556e-04
  4.69892307e-05 3.54508218e-04 3.39318822e-02 5.74383702e-04
  1.24688208e-02 6.54832380e-05]]'''

#引入因子8
f=select_factor(r,v,8,5)
print(f)
#f=79.67412940568431
r=convert_matrix(r,8)
v=get_vari_contri(r)
print(v)
'''[[1.67965775e-02 9.40820657e-04 1.72597733e-02 2.04936304e-04
  9.71232097e-05 9.30427774e-05 3.42948432e-02 5.74383702e-04
  1.25103417e-02 2.29459676e-05]]'''





'''接下来是试验线性回归模型部分'''

from sklearn.linear_model import LinearRegression
#变量初始化
X=[]
Y=[]
#从csv文件中读取数据

def get_data(file_name):
	data=pd.read_csv(file_name,header=0)
	data=np.array(data)
	#数组切片对变量进行赋值
	Y=data[:,data.shape[1]-1]#预报对象位于最后一列
	X=data[:,0:data.shape[1]-1]
	print(X.shape)
	return X,Y
X,Y=get_data('NewData2.csv')
X1,Y1 = get_data('NewData4.csv')
regs=LinearRegression()
regs2=LinearRegression()
regs2.fit(X1,Y1)
regs.fit(X,Y)
print('线性模型1：')
print(regs.coef_)#输出回归系数
print(regs.score(X,Y))#输出相关系数
print('线性模型2：')
print(regs2.coef_)#输出回归系数
print(regs2.score(X1,Y1))#输出相关系数