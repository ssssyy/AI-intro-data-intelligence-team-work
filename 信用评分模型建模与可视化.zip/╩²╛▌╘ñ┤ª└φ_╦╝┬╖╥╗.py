# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import pandas as pd
import matplotlib.pyplot as plt #导入图像库
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import numpy as np
# 用随机森林对缺失值预测填充函数
def set_missing(df):
    # 把已有的数值型特征取出来
    process_df = df.ix[:,[5,0,1,2,3,4,6,7,8,9]]
    # 分成已知该特征和未知该特征两部分
    known = process_df[process_df.MonthlyIncome.notnull()].as_matrix()
    unknown = process_df[process_df.MonthlyIncome.isnull()].as_matrix()
    # X为特征属性值
    X = known[:, 1:]
    # y为结果标签值
    y = known[:, 0]
    # fit到RandomForestRegressor之中
    rfr = RandomForestRegressor(random_state=0, n_estimators=200,max_depth=3,n_jobs=-1)
    rfr.fit(X,y)
    # 用得到的模型进行未知特征值预测
    predicted = rfr.predict(unknown[:, 1:]).round(0)
    #print(predicted)
    # 用得到的预测结果填补原缺失数据
    df.loc[(df.MonthlyIncome.isnull()), 'MonthlyIncome'] = predicted
    return df

if __name__ == '__main__':
    #载入数据
    data = pd.read_csv('cs-training.csv')
    data = set_missing(data)#用随机森林填补比较多的缺失值
    data = data.dropna()#删除比较少的缺失值
    data = data.drop_duplicates()#删除重复项
    
    #异常值处理
    #年龄等于0的异常值进行剔除
    data=data[data['age']>0]
    data = data[data['age'] <= 100]
    data = data[data['NumberOfTime30-59DaysPastDueNotWorse'] < 90]#剔除异常值
    #data = data[data['DebtRatio'] <= 1]
    #data = data[data['RevolvingUtilizationOfUnsecuredLines'] <= 1]
    
    #此处将客户好坏的指标互换，用1表示好客户，0表示坏客户
    data['SeriousDlqin2yrs']=1-data['SeriousDlqin2yrs']
    data.to_csv('TrainData.csv',index=False)
    
    #对test数据集也进行预处理
    data = pd.read_csv('cs-test.csv')
    del data['Unnamed: 0']
    del data['SeriousDlqin2yrs']
    data.age[data['age']>100]=100
    data.RevolvingUtilizationOfUnsecuredLines[data['RevolvingUtilizationOfUnsecuredLines']>1]=1
    data.DebtRatio[data['DebtRatio']>1]=1
    data.NumberOfTimes90DaysLate[data['NumberOfTimes90DaysLate']>80]=18
    data.ix[data['NumberOfTime30-59DaysPastDueNotWorse']>80,'NumberOfTime30-59DaysPastDueNotWorse']=19
    data.ix[data['NumberOfTime60-89DaysPastDueNotWorse']>80,'NumberOfTime60-89DaysPastDueNotWorse']=19
    data.to_csv('TestData.csv',index=False)